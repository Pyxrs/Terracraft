package io.github.simplycmd.terracraft.items.accessories;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;

public class AutoswingAccessoryItem extends AccessoryItem {
    // TODO: Use a mixin to make this accessory have autoswing
    public AutoswingAccessoryItem(FabricItemSettings settings) {
        super(settings);
    }
}
